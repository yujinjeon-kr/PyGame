import random
import pygame
import sys

pygame.init()
encoding = "euc-kr"
WHITE = (255, 255, 255)

#1 화면 크기 설정
window_width, window_height = 1280, 800
window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption("바다를 지켜라!")

#2 음악 사운드 로드
background_music = "all_sounds/main_music.mp3"
collision_sound = pygame.mixer.Sound('all_sounds/sound2.mp3')
collision_sound.set_volume(0.3)
pygame.mixer.music.load(background_music)

#3 메인화면 이미지 로드
background_image = pygame.image.load("all_images/background_opening.png")
background_image = pygame.transform.scale(background_image, (window_width, window_height))

#4 게임설명 이미지 로드
instruction_image = pygame.image.load('all_images/guide.png')
instruction_image = pygame.transform.scale(instruction_image, (window_width, window_height))

#5 메인화면 버튼 이미지 로드
button1_image = pygame.image.load("all_images/game_start.png")
button2_image = pygame.image.load("all_images/game_guide.png")
button3_image = pygame.image.load("all_images/game_exit.png")

#6 화면 나가기 이미지 로드
arrow1_image = pygame.image.load("all_images/arrow1.png")
arrow1_image = pygame.transform.scale(arrow1_image, (48, 40))

#7 메인 게임 화면 로드
gbackground_image = pygame.image.load('all_images/background_ongame.png')
gbackground_image = pygame.transform.scale(gbackground_image, (window_width, window_height))

#8 플레이어 이미지 로드
player_image = pygame.image.load('all_images/fishpole_down.png')
player_rect = player_image.get_rect()
player_rect.x = 50
player_rect.y = window_height//2 - player_rect.height//2
player_speed = 8

#9 물고기 이미지 로드
fish_list = []
for i in range(1,8):
    fish_image = pygame.image.load(f'all_images/fish{i}.png')
    fish_list.append(fish_image)

#10 물고기 기본 위치 설정
fish_rect = fish_image.get_rect()
fish_rect.x = 1300
fish_rect.y = random.randint(60,700)
fish_speed = 3

#11 쓰레기 이미지 로드
trash_list = []
for i in range(1,8):
    trash_image = pygame.image.load(f'all_images/trash{i}.png')
    trash_list.append(trash_image)

#12 쓰레기 기본 위치 설정
trash_rect = fish_image.get_rect()
trash_rect.x = 1300
trash_rect.y = random.randint(60,700)
trash_speed = 3

#13 게임 클리어 화면 로드
clear_image = pygame.image.load("all_images/clear_game.png")
clear_image = pygame.transform.scale(clear_image, (window_width, window_height))

#14 게임 오버 화면 로드
over_image = pygame.image.load("all_images//game_over.png")
over_image = pygame.transform.scale(over_image, (window_width, window_height))

#15 게임 클리어 및 오버 화면 등장 함수 정의
def draw_game_over_screen():
    window.blit(over_image, (0, 0))
def draw_clear_screen():
    window.blit(clear_image, (0, 0))

#16 메인화면 버튼 기본 값 설정
button_width, button_height = 248, 85
button_x, button_y = (window_width - button_width) // 2, window_height // 2

#17 메인화면 버튼 클래스 생성
class Button:
    def __init__(self, x, y, width, height, image):
        self.rect = pygame.Rect(x, y, width, height)
        self.image = image
        self.enabled = True
        self.visible = True
    
    # 게임 화면에 버튼 그리기 함수
    def draw(self, window): 
        if self.visible:
            window.blit(self.image, self.rect)
    
    # 사용자의 버튼클릭 감지 함수
    def is_clicked(self, pos):
        return self.enabled and self.visible and self.rect.collidepoint(pos)
    
    # 버튼 기능 비활성화 함수
    def disable(self):
        self.enabled = False
    
    # 버튼 숨기기 함수
    def hide(self):
        self.visible = False
    
    # 버튼 활성화 함수
    def enable(self):
        self.enabled = True
    
    # 버튼 등장 함수
    def show(self):
        self.visible = True

#18 Button 클래스를 활용하여 버튼 객체 생성
button1 = Button(button_x, button_y, button_width, button_height, button1_image)
button2 = Button(button_x, button_y + 95, button_width, button_height, button2_image)
button3 = Button(button_x, button_y + 190, button_width, button_height, button3_image)
buttons = [button1, button2, button3]

#19 화면 나가기 버튼 객체 생성
arrow1 = Button(1220, 0, 48, 40, arrow1_image)

#20 버튼이미지 3개 그리는 함수
def draw_buttons():
    for button in buttons:
        button.draw(window)

#21 메인화면과 버튼을 그리는 함수
def draw_opening_screen():
    window.blit(background_image, (0, 0))
    draw_buttons()

#22 설명화면과 나가기 버튼을 그리는 함수
def draw_instruction_screen():
    window.blit(instruction_image, (0, 0))
    arrow1.draw(window)


previous_screen = []  # 설명화면으로 넘어간 경우 일정 값을 저장하기 위한 리스트 설정

#23 메인화면에서 버튼을 클릭했을 때 작동하는 함수
def handle_button_click(pos):
    for button in buttons:
        if button.is_clicked(pos): 
            if button == button1: #첫번째 게임시작 버튼을 클릭하면 게임 작동 함수 불러오기
                game_start()
            elif button == button2: #두번째 게임 설명 버튼을 클릭하면 설명 페이지 불러오기
                draw_instruction_screen()
                previous_screen.append("opening")  #previous_screen 리스트에 opening라는 문자열 추가
                for button in buttons: #메인화면에 있던 3개 버튼의 이미지를 숨기기
                    button.hide()
            elif button == button3: #세번째 게임 종료 버튼을 누르면 게임 종료
                pygame.time.delay(30)
                pygame.quit()
                sys.exit()

#24 화면 나가기 버튼 눌렀을 때 작동하는 함수
def handle_arrow_click(pos): #설명화면 나가기 버튼을 누르면 이전 메인화면 불러오는 함수
    if arrow1.is_clicked(pos):
        if previous_screen: #previous_screen "opening"이라는 값이 있으면 해당 값을 삭제
            previous = previous_screen.pop()  
            if previous == "opening":
                draw_opening_screen()
                for button in buttons:
                    button.show()

#25 WQI(수질오염지수)에 따른 색상 변환 함수
def get_wqi_color(wqi):
    if wqi < 24:
        return (0, 0, 255) 
    elif 24 <= wqi < 34:
        return (135, 206, 250)   
    elif 34 <= wqi < 47:
        return (255, 255, 0)  
    elif 47 <= wqi < 60:
        return (255, 165, 0)  
    elif wqi >= 60 :
        return (255,0,0)      

#26 게임 플레이 함수                 
def game_start():
    wqi = 100  
    fish_instances = []
    trash_instances = []

    # 물고기와 쓰레기 리스트에 랜덤으로 이미지 및 기본 값 설정
    for _ in range(4):  
        fish_image = random.choice(fish_list)
        fish_rect = fish_image.get_rect() #get._rect 이미지의 경계 사각형 객체를 반환하는 메서드
        fish_rect.x = window_width
        fish_rect.y = random.randint(60, 700)
        fish_speed = random.uniform(2, 6)  
        fish_instances.append((fish_image, fish_rect, fish_speed)) #fish_instances 리스트 안에 3가지 요소를 튜플 형태로 저장

        trash_image = random.choice(trash_list)
        trash_rect = trash_image.get_rect()
        trash_rect.x = window_width
        trash_rect.y = random.randint(60, 700)
        trash_speed = random.uniform(2, 6)  
        trash_instances.append((trash_image, trash_rect, trash_speed))


    pygame.mixer.music.play(-1) #배경 음악을 반복 재생하는 메서드

    game_over = False
    

    while not game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.mixer.music.stop()
                pygame.quit()
                sys.exit()
        if wqi >=120:
            window.blit(over_image, (0, 0))
            pygame.display.flip()
            # 3초간 대기
            pygame.time.delay(6000)
            # 게임 클리어 화면을 보여준 후 게임 종료
            game_over = True
        elif wqi <=0:
            window.blit(clear_image, (0, 0))
            pygame.display.flip()
            # 3초간 대기
            pygame.time.delay(6000)
            # 게임 클리어 화면을 보여준 후 게임 종료
            game_over = True
        # 플레이어 상태 업데이트
        player_speed=10
        if wqi <= 60:
            # wqi점수가 60점 이하이면 사용자의 속도를 4배로 증가
            player_speed *= 4
        elif wqi>=115:
            player_speed *=0.35
            # wqi점수가 115점 이상이면 사용자의 속도를 저하

        # Player Movement
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            player_rect.y -= player_speed
            if player_rect.y < 50:
                player_rect.y = 50
        elif keys[pygame.K_DOWN]:
            player_rect.y += player_speed
            if player_rect.y > 800 - player_rect.height:
                player_rect.y = 800 - player_rect.height

        # Fish/Trash Movement
        for fish_image, fish_rect, fish_speed in fish_instances:
            fish_rect.x -= fish_speed
            if fish_rect.right < 0:
                fish_rect.y = random.randint(60, 700)
                fish_rect.x = window_width
                

        for trash_image, trash_rect, trash_speed in trash_instances:
            trash_rect.x -= trash_speed
            if trash_rect.right < 0:
                trash_rect.y = random.randint(60, 700)
                trash_rect.x = window_width
                
        # Remove off-screen instances
        fish_instances = [(image, rect, speed) for image, rect, speed in fish_instances if rect.right >= 0]
        trash_instances = [(image, rect, speed) for image, rect, speed in trash_instances if rect.right >= 0]
        # Check for collisions with fish
        for fish_image, fish_rect, _ in fish_instances[:]:  # Use [:] to make a copy of the list
            if player_rect.colliderect(fish_rect):
                wqi += 5
                fish_instances.remove((fish_image, fish_rect, _))
                fish_rect.y = random.randint(60, 700)
                fish_rect.x = window_width
                fish_instances.append((fish_image, fish_rect, fish_speed))
                collision_sound.play()
        # Check for collisions with trash
        for trash_image, trash_rect, _ in trash_instances[:]:  # Use [:] to make a copy of the list
            if player_rect.colliderect(trash_rect):
                wqi -= 10
                trash_instances.remove((trash_image, trash_rect, _))
                trash_rect.y = random.randint(60, 700)
                trash_rect.x = window_width
                trash_instances.append((trash_image, trash_rect, trash_speed))
                collision_sound.play()
        # Draw Images
        window.blit(gbackground_image, (0, 0))
        window.blit(player_image, player_rect)
        for fish_image, fish_rect, _ in fish_instances:
            window.blit(fish_image, fish_rect)
        for trash_image, trash_rect, _ in trash_instances:
            window.blit(trash_image, trash_rect)

        
        # Draw WQI
        wqi_color = get_wqi_color(wqi)
        font = pygame.font.SysFont("malgungothic", 50) #pygame.font.Font(None, 50)
        wqi_text = font.render(f"수질 지수: {wqi}", True, wqi_color)
        window.blit(wqi_text, (10, 10))
        pygame.display.flip()
        

#27 메인 시작화면

while True:
    
    for event in pygame.event.get(): # pygame의 모든 이벤트(사용자 입력)을 저장하는 버퍼를 가져옴
        # 창을 닫기 위해 종료하는 이벤트가 있는지 확인
        # pygame.QUIT : 윈도우의 닫기버튼(X버튼)을 누르는 이벤트
        if event.type == pygame.QUIT:
            pygame.mixer.music.stop()
            # pygame 종료
            pygame.quit()
            # 파이썬 프로그램 종료
            sys.exit()
        # 마우스 버튼을 누르는 이벤트 발생 확인
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == True: # 마우스의 버튼 값을 확인                
                pos = pygame.mouse.get_pos() # 마우스의 커서의 위치를 가져와서 pos 변수에 저장
                
                if previous_screen: #설명페이지에서 버튼 버튼 클릭이 인식되고 previous_screen값이 True으로 된 경우
                    handle_arrow_click(pos) # 이전 페이지가 사라지고(.pop) 메인 페이지와 버튼 등장
                else:
                    handle_button_click(pos) #버튼 클릭 화면이 메인 페이지일 경우, 3가지 버튼이 동작하는 함수 호출

                       
    if previous_screen:
        draw_instruction_screen()
    else:
        draw_opening_screen() #사용자의 키보드값 입력 상관없이 기본 메인화면 설정 

    pygame.display.flip() #화면을 업데이트하는 역할
    pygame.time.Clock().tick(120) #화면이 좀 더 부드럽게 움직일 수 있도록 게임 루프가 초당 120번 실행되도록 설정
import os
os.system('pause')